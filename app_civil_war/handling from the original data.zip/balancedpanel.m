
%read data form the file
[num, txt] = xlsread('civildata.xlsx');
% code_country = csvread('civildata.csv');

%save objective variables separately
ccode = num(:,1);
cmark = num(:,4);
Y = num(:,8); % Y variable: war
%pick desired regressors, here we pick  *** *** as examples
X1 = num(:,19);%here is logpop
X2 = num(:,21);%here is gdp/pop. GDP per capita
X3 = num(:, 53); % democracy

year = num(:,5);

codelist = unique(ccode);
ind_pos = find(cmark == 1);
n = length(ind_pos);
M = length(cmark);
T = 40;
%T = 55;

%delete countries with less than 40 observations
%Firstly check the last country in the list
num_obs = M - ind_pos(n) + 1;
if  num_obs < T
    codelist(n) = -1;
	range = ind_pos(n):M;
	Y(range) = -1 * ones(num_obs,1);
	X1(range) = -1 * ones(num_obs,1);
	X2(range) = -1 * ones(num_obs,1);
    X3(range) = -1 * ones(num_obs,1);
    year(range) = -1 * ones(num_obs,1);
    cmark(range) = -1 * ones(num_obs,1);
end
%Check other countries
for i = 1:(n-1)
	num_obs = ind_pos(i+1) - ind_pos(i);
	if num_obs < T
		codelist(i) = -1;
		range = ind_pos(i):(ind_pos(i+1) - 1);
		Y(range) = -1 * ones(num_obs,1);
		X1(range) = -1 * ones(num_obs,1);
		X2(range) = -1 * ones(num_obs,1);
        X3(range) = -1 * ones(num_obs,1);
        year(range) = -1 * ones(num_obs,1);
        cmark(range) = -1 * ones(num_obs,1);
	end
end
%Deleting
codelist = codelist(codelist ~= -1);
Y = Y(Y ~= -1);
X1 = X1(X1 ~= -1);
X2 = X2(X2 ~= -1);
X3 = X3(X3 ~= -1);
year = year(year ~= -1);
cmark = cmark(cmark ~= -1);

%%

%delete countries that has missing observations during 90s
ind_pos = find(cmark == 1);
n = length(ind_pos);
M = length(cmark);

num_obs = M - ind_pos(n) + 1;
if year(M-9) ~= 1990
    codelist(n) = -1;
	range = ind_pos(n):M;
	Y(range) = -1 * ones(num_obs,1);
	X1(range) = -1 * ones(num_obs,1);
	X2(range) = -1 * ones(num_obs,1);
    X3(range) = -1 * ones(num_obs,1);
    year(range) = -1 * ones(num_obs,1);
    cmark(range) = -1 * ones(num_obs,1);
end

for i = 1:(n-1)
    num_obs = ind_pos(i+1) - ind_pos(i);
	if year(ind_pos(i+1) - 10) ~= 1990
		codelist(i) = -1;
		range = ind_pos(i):(ind_pos(i+1) - 1);
		Y(range) = -1 * ones(num_obs,1);
		X1(range) = -1 * ones(num_obs,1);
		X2(range) = -1 * ones(num_obs,1);
        X3(range) = -1 * ones(num_obs,1);
        year(range) = -1 * ones(num_obs,1);
        cmark(range) = -1 * ones(num_obs,1);
	end
end

codelist = codelist(codelist ~= -1);
Y = Y(Y ~= -1);
X1 = X1(X1 ~= -1);
X2 = X2(X2 ~= -1);
X3 = X3(X3 ~= -1);
year = year(year ~= -1);
cmark = cmark(cmark ~= -1);


%%
%delete observations before 1960 to make the panel data balanced
M = length(year);
for i = 1:M
	if year(i) < 1960
		Y(i) = -1;
		X1(i) = -1;
		X2(i) = -1;
        X3(i) = -1;
	end
end
Y = Y(Y ~= -1);
X1 = X1(X1 ~= -1);
X2 = X2(X2 ~= -1);
X3 = X3(X3 ~= -1);

%%
%This section is intended to reshape the data to desired format and fill in missing entries
T = 40;
N = length(codelist);
y = reshape(Y,T,N);
x1 = reshape(X1,T,N);
x2 = reshape(X2,T,N);
x3 = reshape(X3,T,N);

fill_y = find(isnan(Y) == 1);
fill_x1 = find(isnan(X1) == 1);
fill_x2 = find(isnan(X2) == 1);
fill_x3 = find(isnan(X3) == 1);

K = length(fill_x1);
for i = 1:K
    location = fill_x1(i);
    p = mod(location,T);
    if p == 0
        p = T;
    end
    q = ceil(location/T);
    x1(p,q) = x1(p-1,q);
end

K = length(fill_x2);
T = 40;
for i = 1:K
    location = fill_x2(i);
    p = mod(location,T);
    if p == 0
        p = T;
    end
    q = ceil(location/T);
    x2(p,q) = x2(p-1,q);
end

x3(isnan(x3) == 1) = 0;

X = zeros(T,N,2);
X(:,:,1) = x1;
X(:,:,2) = x2;
X(:,:,3) = x3;


% in total 102 countries
save('input_balanced_new.mat')